const Discord = require('discord.js');
const fs = require('fs');
const client = new Discord.Client();
const { MessageEmbed } = require('discord.js');
const fetch = require('node-fetch');
const config = require('./config.json');
let autoLineChannels = require('./channels.json');
const reactionListeners = {};
client.login(config.token);
client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
  console.log(`Code by Wick Eric`);
  client.user.setActivity("with depression", {
    type: "STREAMING",
    url: "https://www.twitch.tv/iseventyone/about"
  });
})

client.on('message', message => {
  if (message.author.bot) return;

  if (message.content === '-line' && message.member.hasPermission('ADMINISTRATOR')) {
    const channelId = message.channel.id;
    let embed;

    if (autoLineChannels.includes(channelId)) {
      autoLineChannels = autoLineChannels.filter(id => id !== channelId);
      embed = new MessageEmbed()
        .setColor('#FF0000')
        .setTitle('❌ Channel Update')
        .setDescription('This channel has been removed from the auto line channels.');
    } else {
      autoLineChannels.push(channelId);
      let attachment = message.attachments.first();
      if (attachment && attachment.url) {
        config.lineImageUrl = attachment.url;
        embed = new MessageEmbed()
          .setColor('#00FF00')
          .setTitle('✅ Channel Update')
          .setDescription('This channel has been added to the auto line channels.')
          .setImage(attachment.url);
      } else {
        return message.channel.send("Please attach an image with your command to set it as the line image.");
      }
    }

    message.channel.send(embed)
      .catch(console.error);

    fs.writeFile('./channels.json', JSON.stringify(autoLineChannels, null, 4), err => {
      if (err) console.error(err);
    });
  }

  if (autoLineChannels.includes(message.channel.id)) {
    message.channel.send({ content: config.lineImageUrl })
      .catch(console.error);
  }
});
let owner = ['520774569855025152','id 2']
client.on('message', async message => {
  if(message.content.startsWith('set-playing')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'PLAYING' })
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
  if(message.content.startsWith('set-listening')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'LISTENING' })
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
  if(message.content.startsWith('set-watching')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'WATCHING' })
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
  if(message.content.startsWith('set-competing')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'COMPETING' })
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
  if(message.content.startsWith('set-streaming')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'STREAMING', url : `https://www.twitch.tv/${ac}`})
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
});
client.on('message', async (message) => {
    // Check if the message starts with the command and is not sent by the bot itself
    if (message.content.startsWith('-react') && !message.author.bot) {
      // Check if the user has administrative permissions
      if (!message.member.hasPermission('ADMINISTRATOR')) {
        return message.channel.send('ليس لديك الصلاحية لاستخدام هذا الأمر.');
      }
      
      // Split the message into command and arguments
      const args = message.content.split(' ');
      
      // Check if the command has the correct number of arguments
      if (args.length === 3) {
        const emoji = args[1];
        let channelID = args[2];
        
        // Check if the third argument is a channel mention
        if (message.mentions.channels.size === 1) {
          channelID = message.mentions.channels.first().id;
        }
        
        try {
          // Get the channel object using the provided ID
          const channel = await client.channels.fetch(channelID);
          
          // Check if the channel is a text channel
          if (channel.type === 'text') {
            // React to new messages in the channel with the specified emoji
            reactionListeners[channelID] = (newMessage) => {
              if (message.author.bot) return;
              if (newMessage.channel.id === channelID) 
              { 
                newMessage.react(emoji).catch(console.error);
              }
            };
            client.on('message', reactionListeners[channelID]);
            message.channel.send(`تم تفعل الرياكشن في شات: ${channel.toString()}  ${emoji} .`);
          } else {
            message.channel.send('ايدي الشات خطأ');
          }
        } catch (error) {
          console.error('Failed to fetch channel:', error);
          message.channel.send('الشات غير موجود او البوت لا يملك صالحيات على الشات');
        }
      } else {
        message.channel.send('الامر خطأ. استخدم: -react <emoji> <channel>');
      }
    } else if (message.content.startsWith('-unreact') && !message.author.bot) {
      // Check if the user has administrative permissions
      if (!message.member.hasPermission('ADMINISTRATOR')) {
        return message.channel.send('ليس لديك الصلاحية لاستخدام هذا الأمر.');
      }
      
      const args = message.content.split(' ');
      if (args.length === 2) {
        let channelID = args[1];
        
        // Check if the second argument is a channel mention
        if (message.mentions.channels.size === 1) {
          channelID = message.mentions.channels.first().id;
        }
        
        // Check if there's an active listener for the specified channel
        if (reactionListeners[channelID]) {
          // Remove the listener
          client.removeListener('message', reactionListeners[channelID]);
          delete reactionListeners[channelID];
          message.channel.send(`لا يوجد رياكشن مفعل في هذا الشات ${message.mentions.channels.first()}.`);
        } else {
          message.channel.send(`لا يوجد رياكشن مفعل في هذا الشات ${message.mentions.channels.first()}.`);
        }
      } else {
        message.channel.send('الامر خطأ. استخدم: -unreact <channel>');
      }
    }
  });
  client.on('message', async (message) => {
    if (message.content.startsWith('setname') && owner.includes(message.author.id)) {
      const newName = message.content.split(' ').slice(1).join(' ');
      if (!newName) return message.channel.send('Please provide a new name.');
      try {
        await client.user.setUsername(newName);
        message.channel.send(`Username changed to ${newName}`);
      } catch (error) {
        console.error('Failed to change username:', error);
        message.channel.send('Failed to change username.');
      }
    }
  
    if (message.content.startsWith('setava') && owner.includes(message.author.id)) {
      const attachment = message.attachments.first();
      if (!attachment) return message.channel.send('Please attach an image to set as the new avatar.');
      try {
          const response = await fetch(attachment.url);
          const buffer = await response.arrayBuffer();
          await client.user.setAvatar(Buffer.from(buffer));
          message.channel.send('Avatar changed successfully!');
      } catch (error) {
          console.error('Failed to change avatar:', error);
          message.channel.send('Failed to change avatar.');
      }
  }
  client.on('message', message => {
    if (message.author.bot) return;
  
    if (message.content === '-help') 
    if (message.member.hasPermission('ADMINISTRATOR')){
      const embed = new MessageEmbed()
        .setColor('#FFA500')
        .setTitle('قائمة الاوامر')
        .setDescription('يمكنك استخدام الاوامر التالية ')
        .addField('setava', 'لتغير صورة البوت')
        .addField('setname', 'لتغير اسم البوت')
        .addField('-line', 'لوضع خط للشات')
        .addField('-react', 'رياكشن تلقائي')
        .addField('-unreact', 'حذف الرياكشن');
  
      message.channel.send(embed)
        .catch(console.error);
    }
  })
  });