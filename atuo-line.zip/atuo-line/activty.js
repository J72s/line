let owner = ['id 1 ','id 2']
client.on('message', async message => {
  if(message.content.startsWith('set-playing')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'PLAYING' })
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
  if(message.content.startsWith('set-listening')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'LISTENING' })
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
  if(message.content.startsWith('set-watching')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'WATCHING' })
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
  if(message.content.startsWith('set-competing')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'COMPETING' })
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
  if(message.content.startsWith('set-streaming')) {
  if(!owner.includes(message.author.id)) return;
  const ac = message.content.split(" ").slice(1).join(" ")
  if(!ac) return message.channel.send('**Activity ?**')
  client.user.setActivity(ac,{ type : 'STREAMING', url : `https://www.twitch.tv/${ac}`})
  message.channel.send(`**Set Activity ${ac} ✅**`)
  }
});