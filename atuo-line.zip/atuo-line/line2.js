const Discord = require('discord.js');
const fs = require('fs');
const client = new Discord.Client();
const { MessageEmbed } = require('discord.js');
const fetch = require('node-fetch');
const config = require('./config.json');
let autoLineChannels = require('./channels.json');
const reactionListeners = {};
const owner = ['520774569855025152', 'id 2'];

client.login(config.token);

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
  console.log(`Code by Wick Eric`);
  client.user.setActivity("with depression", {
    type: "STREAMING",
    url: "https://www.twitch.tv/iseventyone/about"
  });
});

client.on('message', message => {
  // Ignore messages from bots
  if (message.author.bot) return;

  if (message.content.startsWith('-line') && message.member.hasPermission('ADMINISTRATOR')) {
    const channelId = message.channel.id;
    let embed;

    if (autoLineChannels.includes(channelId)) {
      autoLineChannels = autoLineChannels.filter(id => id !== channelId);
      embed = new MessageEmbed()
        .setColor('#FF0000')
        .setTitle('❌ Channel Update')
        .setDescription('This channel has been removed from the auto line channels.');
    } else {
      autoLineChannels.push(channelId);
      let attachment = message.attachments.first();
      if (attachment && attachment.url) {
        config.lineImageUrl = attachment.url;
        embed = new MessageEmbed()
          .setColor('#00FF00')
          .setTitle('✅ Channel Update')
          .setDescription('This channel has been added to the auto line channels.')
          .setImage(attachment.url);
      } else {
        return message.channel.send("Please attach an image with your command to set it as the line image.");
      }
    }

    message.channel.send(embed)
      .catch(console.error);

    fs.writeFile('./channels.json', JSON.stringify(autoLineChannels, null, 4), err => {
      if (err) console.error(err);
    });
  }

  if (autoLineChannels.includes(message.channel.id)) {
    message.channel.send({ content: config.lineImageUrl })
      .catch(console.error);
  }

  if (message.content.startsWith('set-playing') || message.content.startsWith('set-listening') || message.content.startsWith('set-watching') || message.content.startsWith('set-competing') || message.content.startsWith('set-streaming')) {
    const [command, activityType, ...activity] = message.content.split(" ");
    if (!owner.includes(message.author.id)) return;
    if (!activity.join(" ")) return message.channel.send('**Activity ?**');

    let url = '';
    if (activityType.toLowerCase() === 'streaming') {
      url = `https://www.twitch.tv/${activity.join(" ")}`;
    }

    client.user.setActivity(activity.join(" "), { type: activityType.toUpperCase(), url: url })
      .then(() => {
        message.channel.send(`**Set Activity ${activity.join(" ")} ✅**`);
      })
      .catch(error => {
        console.error('Failed to set activity:', error);
        message.channel.send('Failed to set activity.');
      });
  }

  if (message.content.startsWith('setname') && owner.includes(message.author.id)) {
    const newName = message.content.split(' ').slice(1).join(' ');
    if (!newName) return message.channel.send('Please provide a new name.');
    client.user.setUsername(newName)
      .then(() => {
        message.channel.send(`Username changed to ${newName}`);
      })
      .catch(error => {
        console.error('Failed to change username:', error);
        message.channel.send('Failed to change username.');
      });
  }

  if (message.content.startsWith('setava') && owner.includes(message.author.id)) {
    const attachment = message.attachments.first();
    if (!attachment) return message.channel.send('Please attach an image to set as the new avatar.');
    fetch(attachment.url)
      .then(response => response.arrayBuffer())
      .then(buffer => client.user.setAvatar(Buffer.from(buffer)))
      .then(() => {
        message.channel.send('Avatar changed successfully!');
      })
      .catch(error => {
        console.error('Failed to change avatar:', error);
        message.channel.send('Failed to change avatar.');
      });
  }

  if (message.content === '-help' && message.member.hasPermission('ADMINISTRATOR')) {
    const embed = new MessageEmbed()
      .setColor('#FFA500')
      .setTitle('Command List')
      .setDescription('You can use the following commands:')
      .addField('setava', 'Change the bot\'s avatar')
      .addField('setname', 'Change the bot\'s name')
      .addField('-line', 'Toggle channel for automatic line messages')
      .addField('-react', 'Set up automatic reactions')
      .addField('-unreact', 'Remove automatic reactions');

    message.channel.send(embed)
      .catch(console.error);
  }
});

client.on('message', async (message) => {
  if ((message.content.startsWith('-react') || message.content.startsWith('-unreact')) && !message.author.bot) {
    if (!message.member.hasPermission('ADMINISTRATOR')) {
      return message.channel.send('You do not have permission to use this command.');
    }

    const args = message.content.split(' ');
    const command = args[0];
    
    if (command === '-react') {
        // react command
        if (args.length === 3) {
          const emoji = args[1];
          let channelID = args[2];
          
          if (message.mentions.channels.size === 1) {
            channelID = message.mentions.channels.first().id;
          }
          
          try {
            const channel = await client.channels.fetch(channelID);
            
            if (channel.type === 'text') {
              reactionListeners[channelID] = (newMessage) => {
                if (newMessage.author.bot || newMessage.author.id === client.user.id) return; // Ignore messages from bots and itself
                if (newMessage.channel.id === channelID) {
                  newMessage.react(emoji).catch(console.error);
                }
              };
              client.on('message', reactionListeners[channelID]);
              message.channel.send(`Reaction activated in: ${channel.toString()} ${emoji}.`);
            } else {
              message.channel.send('Invalid channel ID.');
            }
          } catch (error) {
            console.error('Failed to fetch channel:', error);
            message.channel.send('The channel does not exist or the bot lacks permissions for the channel.');
          }
        } else {
          message.channel.send('Invalid command. Use: -react <emoji> <channel>');
        }
      } 
    }
});

